package com.example.assignment_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
